//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include "libpq-fe.h"

#include <Grids.hpp>
//---------------------------------------------------------------------------
class TAlt_start : public TForm
{
__published:	// IDE-managed Components
        TOpenDialog *OpenDialog_mgdr;
        TOpenDialog *OpenDialog_tle;
        TImage *Image_Cool;
        TButton *Button_start;
        TButton *Button_exit;
        TGroupBox *Mode_work;
        TRadioButton *Radio_calc_topex;
        TRadioButton *Radio_calc_jason1;
        TGroupBox *GroupBox1;
        TLabel *Label_Mgdr;
        TButton *Button_mgdr;
        TGroupBox *GroupBox2;
        TLabel *Label_Tle;
        TButton *Button_tle;
        TGroupBox *PostgresBox;
        TLabel *PL_server;
        TLabel *PL_dbname;
        TLabel *PL_password;
        TLabel *PL_user;
        TEdit *PE_server;
        TEdit *PE_dbname;
        TEdit *PE_password;
        TEdit *PE_user;
        TButton *Button_testconnect;
        TProgressBar *Progress_mgdr;
        TProgressBar *Progress_tle;
        TProgressBar *Progress_mgdr_file;
        TProgressBar *Progress_mgdr_dir;
        TButton *Button_cancel;
        TListBox *Status_help;
        TRadioButton *Radio_calc_envi;
        void __fastcall Button_exitClick(TObject *Sender);
        void __fastcall Button_startClick(TObject *Sender);
        void __fastcall Button_mgdrClick(TObject *Sender);
        void __fastcall Button_tleClick(TObject *Sender);
        void __fastcall ThreadDone(TObject *Sender);
        void __fastcall Button_cancelClick(TObject *Sender);
        void __fastcall Button_testconnectClick(TObject *Sender);
        void __fastcall Radio_calc_jason1Click(TObject *Sender);
        void __fastcall Radio_calc_topexClick(TObject *Sender);
        void __fastcall Radio_calc_enviClick(TObject *Sender);
private:	// User declarations
        AnsiString Buffer1;
public:		// User declarations
        __fastcall TAlt_start(TComponent* Owner);

HINSTANCE LIBPQ;
    PGconn     *conn;
    PGresult   *res;
        PGconn *(__stdcall *PQconnectdb)(const char *conninfo);
        void (__stdcall *PQfinish)(PGconn *conn);
        ConnStatusType (__stdcall *PQstatus)(const PGconn *conn);
        char *(__stdcall *PQerrorMessage)(const PGconn *conn);
        PGresult *(__stdcall *PQexec)(PGconn *conn,const char *command);
        ExecStatusType (__stdcall *PQresultStatus)(const PGresult *res);
        void (__stdcall *PQclear)(PGresult *res);

};
//---------------------------------------------------------------------------
extern PACKAGE TAlt_start *Alt_start;
//---------------------------------------------------------------------------
#endif
