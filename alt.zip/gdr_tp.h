#ifndef TopexHeaderH
#define TopexHeaderH

#define Header1 33*228
#define GDRM_RECSIZE 228
#define NUM_GDRM_HEADER_RECORDS 33

#define Alt_Min 1200000000
#define Alt_Max 1400000000
#define Alt_Def 2147483647

struct gdrm_tp_header{

   /* TIME */
//   unsigned char   Tim_Moy[8];
   short           Tim_Moy_1;
   int            Tim_Moy_2;
   short           Tim_Moy_3;
   int            Dtim_Mil;	/* microsec */
   int            Dtim_Bias;	/* microsec */
   int            Dtim_Pac;	/* microsec */

   /* LOCATION */
   int             Lat_Tra;	/* microdeg */
   int             Lon_Tra;	/* microdeg */

   /* ALTITUDE */
   int             Sat_Alt;		/* mm */
   int             HP_Sat;		/* mm */
   short           Sat_Alt_Hi_Rate[10];	/* mm */
   short           HP_Sat_Hi_Rate[10];	/* mm */

   /* ATTITUDE */
   unsigned char   Att_Wvf;		/* 0.01 deg */
   unsigned char   Att_Ptf;		/* 0.01 deg */

   /* RANGES */
   int             H_Alt;		/* mm */
   short           H_Alt_SME[10];	/* mm */
   signed char     Nval_H_Alt;		/* counts */
   short           RMS_H_Alt;		/* mm */
   short           Net_Instr_R_Corr_K;	/* mm */
   short           Net_Instr_R_Corr_C;	/* mm */
   signed char     Cg_Range_Corr;	/* mm */
   short           Range_Deriv;		/* 0.01 m/s */
   short           RMS_Range_Deriv;	/* 0.01 m/s */

   /* ENVIR CORR */
   short           Dry_Corr;	/* mm */
   short           Dry1_Corr;	/* mm */
   short           Dry2_Corr;	/* mm */
   short           INV_BAR;	/* mm */
   short           Wet_Corr;	/* mm */
   short           Wet1_Corr;	/* mm */
   short           Wet2_Corr;	/* mm */
   short           Wet_H_Rad;	/* mm */
   short           Iono_Corr;	/* mm */
   short           Iono_Dor;	/* mm */
   short           Iono_Ben;	/* mm */

   /* SWH */
   unsigned short  SWH_K;		    /* 0.1 m */
   unsigned short  SWH_C;		    /* 0.1 m */
//   unsigned char   SWH_K;		    /* 0.1 m */
//   unsigned char   SWH_C;		    /* 0.1 m */
   unsigned char   SWH_RMS_K;		    /* 0.1 m */
   unsigned char   SWH_RMS_C;		    /* 0.1 m */
   signed char     SWH_Pts_Avg;		    /* counts */
   signed char     Net_Instr_SWH_Corr_K;    /* 0.1 m */
   signed char     Net_Instr_SWH_Corr_C;    /* 0.1 m */
   short           DR_SWH_Att_K;	    /* mm */
   short           DR_SWH_Att_C;	    /* mm */
   short           EMB_Gaspar;  	    /* mm */
   short           EMB_Walsh;   	    /* mm */

   /* SIGMA-0 */
   short  	   Sigma0_K;		    /* 0.01 dB */
   short  	   Sigma0_C;		    /* 0.01 dB */
   short  	   AGC_K;		    /* 0.01 dB */
   short  	   AGC_C;		    /* 0.01 dB */
   short           AGC_RMS_K;		    /* 0.01 dB */
   unsigned char   AGC_RMS_C;		    /* 0.01 dB */
   unsigned char   Atm_Att_Sig0_Corr;	    /* 0.01 dB */
   short           Net_Instr_Sig0_Corr;	    /* 0.01 dB */
   short           Net_Instr_AGC_Corr_K;    /* 0.01 dB */
   short           Net_Instr_AGC_Corr_C;    /* 0.01 dB */
   signed char     AGC_Pts_Avg;		    /* counts */

   /* GEOPH QUANT */
   int             H_MSS;	/* mm */
   int             H_Geo;	/* mm */
   short           H_EOT_CSR;	/* mm */
   short           H_EOT_FES;	/* mm */
   short           H_LT;	/* mm */
   short           H_Set;	/* mm */
   signed char     H_Pol;	/* mm */
   unsigned char   Wind_Sp;	/* 0.1 m/s */
   short           H_Ocs;	/* m */

   /* TMR */
   short           Tb_18;	/* 0.01 deg K */
   short           Tb_21;	/* 0.01 deg K */
   short           Tb_37;	/* 0.01 deg K */

   /* FLAGS */
   signed char     ALTON;		/* n/a */
   unsigned char   Instr_State_Topex;	/* n/a */
   unsigned char   Instr_State_TMR;	/* n/a */
   signed char     Instr_State_DORIS;	/* n/a */
   signed char     IMANV;		/* n/a */
   signed char     Lat_Err;		/* n/a */
   signed char     Lon_Err;		/* n/a */
   signed char     Val_Att_Ptf;		/* n/a */
   unsigned char   Current_Mode_1;	/* n/a */
   unsigned char   Current_Mode_2;	/* n/a */
   unsigned char   Gate_Index;		/* n/a */
   signed char     Ind_Pha;		/* n/a */
   unsigned short  Rang_SME;		/* n/a */
   unsigned char   Alt_Bad_1;		/* n/a */
   unsigned char   Alt_Bad_2;		/* n/a */
   signed char     Fl_Att;		/* n/a */
   signed char     Dry_Err;		/* n/a */
   signed char     Dry1_Err;		/* n/a */
   signed char     Dry2_Err;		/* n/a */
   signed char     Wet_Flag;		/* n/a */
   signed char     Wet_H_Err;		/* n/a */
   short           Iono_Bad;		/* n/a */
   signed char     Iono_Dor_Bad;	/* n/a */
   unsigned char   Geo_Bad_1;		/* n/a */
   unsigned char   Geo_Bad_2;		/* n/a */
   unsigned char   TMR_Bad;		/* n/a */
   unsigned char   Ind_RTK;		/* n/a */
   unsigned char            Spare;	/* n/a */
};
#endif

