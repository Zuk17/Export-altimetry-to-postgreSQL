//
// cJulian.h
//
// Copyright (c) 2003 Michael F. Henry
//
#ifndef cJulianH
#define cJulianH
#include <time.h>

//
// See note in cJulian.cpp for information on this class and the epoch dates
//
const double EPOCH_JAN1_00H_1900 = 2415019.5; // Jan 1.0 1900 = Jan 1 1900 00h UTC
const double EPOCH_JAN1_12H_1900 = 2415020.0; // Jan 1.5 1900 = Jan 1 1900 12h UTC
const double EPOCH_JAN1_12H_2000 = 2451545.0; // Jan 1.5 2000 = Jan 1 2000 12h UTC

//////////////////////////////////////////////////////////////////////////////
class cJulian  
{
public:
   cJulian() { Initialize(2000, 1); }
   cJulian(const cJulian &j) { m_Date = j.m_Date; }
   explicit cJulian(time_t t);              // Create from time_t
   explicit cJulian(int year, double day);  // Create from year, day of year

   virtual ~cJulian() {};

   double toGMST() const;           // Greenwich Mean Sidereal Time
   double toLMST(double lon) const; // Local Mean Sideral Time
   time_t toTime() const;           // To time_t type

   double FromJan1_00h_1900() const { return m_Date - EPOCH_JAN1_00H_1900; }
   double FromJan1_12h_1900() const { return m_Date - EPOCH_JAN1_12H_1900; }
   double FromJan1_12h_2000() const { return m_Date - EPOCH_JAN1_12H_2000; }

   void getComponent(int *pYear, int *pMon = NULL, double *pDOM = NULL) const;
   double getDate() const { return m_Date; }

   void addDay(double day) { m_Date += day;                   }
   void addHour(double hr) { m_Date += (hr / 24.0);           }
   void addMin(double min) { m_Date += ((min / 60.0) / 24.0); }

   double Mins(const cJulian& b) const; // Number of minutes between two dates.

protected:
   void Initialize(int year, double day);

   double m_Date; // Julian date
};
#endif
