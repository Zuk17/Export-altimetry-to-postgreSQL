/* 
include file: j1gdr_passdata.h
This include file defines the structure of the jason1 GDR pass
file data record.  Record size = 440 bytes.
"n/a" = not applicable (no units for the parameter)
*/ 

#ifndef GdrG1H
#define GdrG1H
struct gdr_j1_header{

/* TIME TAG */
unsigned long time_day;      /* num days from reference date (days)     */
unsigned long time_sec;      /* seconds within day           (sec)      */
unsigned long time_microsec; /* microseconds within sec      (microsec) */

/* LOCATION AND SURFACE TYPE */
signed long latitude;        /* latitude                (microdeg) */
unsigned long longitude;     /* longitude               (microdeg) */
unsigned char surface_type;  /* surface_type            (n/a)      */
unsigned char alt_echo_type; /* altimeter_echo_type     (n/a)      */
unsigned char rad_surf_type; /* radiometer_surface_type (n/a)      */

/* QUALITY INFORMATION AND SENSORS STATUS */
unsigned char qual_1hz_alt_data;       /* qual flag 1Hz alt data        (n/a) */
unsigned char qual_1hz_alt_instr_corr; /* qual flag 1Hz alt instr corr  (n/a) */
unsigned char qual_1hz_rad_data;       /* qual flag 1Hz radiometer data (n/a) */
unsigned char alt_state_flag;          /* altimeter state flag          (n/a) */
unsigned char rad_state_flag;          /* radiometer state flag         (n/a) */
unsigned char orb_state_flag;          /* orbit state flag              (n/a) */
unsigned char qual_spare[3];           /* spare                         (n/a) */

/* ORBIT */
unsigned long altitude;      /* 1 Hz altitude of satellite           (10-4 m) */
signed long alt_hi_rate[20]; /* diff alt elementary meas to ave meas (10-4 m) */
signed short int orb_alt_rate;   /* orbital altitude rate                (cm/s)   */
unsigned char orb_spare[2];  /* spare                                (n/a)    */

 /* ALTIMETER RANGE */
unsigned long range_ku;          /* 1 Hz Ku range                          (10-4 m) */
signed long range_hi_rate_ku[20];/* diff of elementary Ku and ave Ku range (10-4 m) */
unsigned long range_c;           /* 1 Hz C range                           (10-4 m) */
signed long range_hi_rate_c[20]; /* diff of elementary C and ave C range   (10-4 m) */
unsigned short int range_rms_ku;     /* RMS of Ku range                        (10-4 m) */
unsigned short int range_rms_c;      /* RMS of C range                         (10-4 m) */
unsigned char range_numval_ku;   /* Num valid pts for Ku range             (n/a)    */
unsigned char range_numval_c;    /* Num valid pts for C range              (n/a)    */
unsigned char alt_spare[2];      /* spare                                  (n/a)    */
unsigned long range_mapvalpts_ku;/* map of valid pts for Ku range          (n/a)    */
unsigned long range_mapvalpts_c; /* map of valid pts for C range           (n/a)    */

 /* ALTIMETER RANGE CORRECTIONS */
signed long net_instr_corr_ku;    /* net instrumental corr on Ku range (10-4 m) */
signed long net_instr_corr_c;     /* net instrumental corr on C range  (10-4 m) */
signed short int model_dry_tropo_corr;/* model dry tropo corr              (10-4 m) */
signed short int model_wet_tropo_corr;/* model wet tropo corr              (10-4 m) */
signed short int rad_wet_tropo_corr;  /* radiometer wet tropo corr         (10-4 m) */
signed short int iono_corr_alt_ku;    /* altimeter iono corr on Ku         (10-4 m) */
signed short int iono_corr_doris_ku;  /* Doris iono corr on Ku             (10-4 m) */
signed short int sea_state_bias_ku;   /* sea state bias corr in Ku         (10-4 m) */
signed short int sea_state_bias_c;    /* sea state bias corr in C          (10-4 m) */
signed short int sea_state_bias_comp; /* composite sea state bias corr     (10-4 m) */

 /* SIGNIFICANT WAVEHEIGHT */
unsigned short int swh_ku;      /* Ku sig wave height                        (mm)  */
unsigned short int swh_c;       /* C sig wave height                         (mm)  */
unsigned short int swh_rms_ku;  /* RMS of Ku sig wave height                 (mm)  */
unsigned short int swh_rms_c;   /* RMS of C sig wave height                  (mm)  */
unsigned char swh_numval_ku;/* num val pts to compute Ku sig wave height (n/a) */
unsigned char swh_numval_c; /* num val pts to compute C sig wave height  (n/a) */

 /* SIGNIFICANT WAVEHEIGHT CORRECTIONS */
signed short int net_instr_corr_swh_ku;/* net instr corr on Ku sig wave height (mm) */
signed short int net_instr_corr_swh_c; /* net instr corr on C sig wave height  (mm) */

 /* BACKSCATTER COEFFICIENT */
unsigned short int sig0_ku;      /* Ku backscatt coeff                        (10-2 dB) */
unsigned short int sig0_c;       /* C backscatt coeff                         (10-2 dB) */
unsigned short int sig0_rms_ku;  /* RMS of Ku backscatt coeff                 (10-2 dB) */
unsigned short int sig0_rms_c;   /* RMS of C backscatt coeff 		  (10-2 dB) */
unsigned char sig0_numval_ku;/* num val pts to compute Ku backscatt coeff (n/a)     */
unsigned char sig0_numval_c; /* num val pts to compute C backscatt coeff  (n/a)     */
unsigned short int agc_ku;       /* Ku AGC                                    (10-2 dB) */
unsigned short int agc_c;        /* C AGC                                     (10-2 dB) */
unsigned short int agc_rms_ku;   /* RMS of Ku AGC                             (10-2 dB) */
unsigned short int agc_rms_c;    /* RMS of C AGC                              (10-2 dB) */
unsigned char agc_numval_ku; /* num val pts to compute Ku AGC             (n/a)     */
unsigned char agc_numval_c;  /* num val pts to compute C AGC              (n/a)     */

 /* BACKSCATTER COEFFICIENT CORRECTIONS */
signed short int net_instr_sig0_corr_ku;/* net instr corr on Ku backscatt coeff   (10-2 dB) */
signed short int net_instr_sig0_corr_c; /* net instr corr on C backscatt coeff    (10-2 dB) */
signed short int atmos_sig0_corr_ku;    /* atmos atten corr on Ku backscatt coeff (10-2 dB) */
signed short int atmos_sig0_corr_c;     /* atmos atten corr on C backscatt coeff  (10-2 dB) */

 /* OFF NADIR ANGLE */
signed short int off_nadir_angle_ku_wvf;/* square of off nadir angle from Ku waveforms  (10-4 deg2) */
signed short int off_nadir_angle_ptf;   /* square of off nadir angle from platform data (10-4 deg2) */

 /* BRIGHTNESS TEMPERATURES */
unsigned short int tb_187; /* 18.7 GHz  brightness temp (10-2 deg K) */
unsigned short int tb_238; /* 23.8 GHz  brightness temp (10-2 deg K) */
unsigned short int tb_340; /* 34.0 GHz  brightness temp (10-2 deg K) */

 /* GEOPHYSICAL PARAMETERS */
signed long int mss; /* mean sea surface height                                         (10-4 m) */
signed long int mss_tp_along_trk; /* TP along int-track mean sea surface            (10-4 m) */
signed long int geoid;            /* geoid height                                       (10-4 m) */
signed short int bathymetry;      /* ocean depth/land elevation                         (m)      */
signed short int inv_bar_corr;    /* inverted barometer height corr                     (10-4 m) */
signed short int hf_fluctuations_corr;/* high freq fluctuations of sea surf topography  (10-4 m) */
unsigned char geo_spare[2];   /* spare                                              (n/a)    */
signed long int ocean_tide_sol1;  /* geocentric ocean tide height solution 1            (10-4 m) */
signed long int ocean_tide_sol2;  /* geocentric ocean tide height solution 2            (10-4 m) */
signed short int ocean_tide_equil;/* equilibrium long int-period ocean tide height      (10-4 m) */
signed short int ocean_tide_non_equil;/* non-equilibrium long int-period ocean tide height  (10-4 m) */
signed short int load_tide_sol1;  /* load tide hght for geocentric ocean tide solution1 (10-4 m) */
signed short int load_tide_sol2;  /* load tide hght for geocentric ocean tide solution2 (10-4 m) */
signed short int solid_earth_tide;/* solid earth tide height                            (10-4 m) */
signed short int pole_tide;       /* geocentric pole tide height                        (10-4 m) */

 /* ENVIRONMENTAL PARAMETERS */
signed short int wind_speed_model_u;/* U component of model wind vector (cm/s) */
signed short int wind_speed_model_v;/* V component of model wind vector (cm/s) */
unsigned short int wind_speed_alt;  /* altimeter wind speed             (cm/s) */
unsigned short int wind_speed_rad;  /* radiometer wind speed            (cm/s) */
signed short int rad_water_vapor;   /* radiometer water vapor content   (10-2 g/cm2) */
signed short int rad_liquid_water;  /* radiometer liquid water          (10-2 Kg/m2) */


 /* FLAGS */
unsigned char ecmwf_meteo_map_avail; /* ECMWF meteorological map availability (n/a) */
unsigned char tb_interp_flag;/* radiometer brightness temp interpolation flag (n/a) */
unsigned char rain_flag;     /* rain flag                                     (n/a) */
unsigned char ice_flag;      /* ice flag                                      (n/a) */
unsigned char interp_flag;   /* interpolation flag                            (n/a) */
unsigned char flag_spare[3]; /* spare                                         (n/a) */
};

#endif