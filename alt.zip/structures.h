#ifndef structuresH
#define structuresH

typedef struct stTleData
{
        int year;
        int day;
        double time;
        char str1[256];
        char str2[256];
}TleElem;

struct struct_header
{
        AnsiString Prod_Agency_Name,Prod_Inst_Name,Source_Name,Sensor_Name,Data_Hand_Ref;
        AnsiString Prod_Cr_Start,Prod_Cr_End,Gen_Soft_Name,Build_ID,Pass_File_Data_Type,POS_Range_Bias;
        AnsiString Topex_Range_Bias, T_P_Sigma0_Offset,NASA_Orbit_FileName,Orbit_Qual_NASA;
        AnsiString CNES_Orbit_FileName,Orbit_Qual_CNES,Topex_Pass_File_ID,POS_Pass_File_ID;
        AnsiString CORIOTROP_File_ID,Cycle_Number,Pass_Number,Pass_Data_Count,Rev_Number,Equator_Long,Equator_Time;
        AnsiString Time_First_Pt,Time_Last_Pt,Time_Epoch;
};

#endif
