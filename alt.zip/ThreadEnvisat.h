//---------------------------------------------------------------------------

#ifndef ThreadEnviH
#define ThreadJEnviH
//---------------------------------------------------------------------------
#include <Classes.hpp>

#include "structures.h"
#include "libpq-fe.h"

#include "main.h"

#include "gdr_envi.h"

#include "fstream.h"


#define J1GDR_RECSIZE 440
#define TOTAL_J1GDR_HEADER_CHARS 3520
//---------------------------------------------------------------------------
class EnviThread : public TThread
{
private:
protected:
        TStringList *ListOut;
        TStringList *DirList;
        TStringList *List_Debug;
        DynamicArray<stTleData> TleData_List;
        BOOL AltCount(void);
        BOOL GETPASSHDR (AnsiString);
        bool decode(unsigned char *buf);
        BOOL CreatingTleDB (AnsiString Path_to_tle);
        void CalculatingGDR (AnsiString Path_to_DATA);
        void GETBITS(char zn,bool *bits);
        AnsiString DATETIMEASTIMATION(int days,int s,int mcs);
        BOOL GETDATETIMEDVUCUR(AnsiString String);

        int swapbyte(char buf [], int start_byte, int num_bytes);

        TSearchRec sr;
        long H_SAT,H_Alt,Wet_Cor,Dry_Cor,EMB,Iono_Cor,INV_BAR,H_EOT,H_SET,H_LT,H_MSS,H_GEO,H_POL,Iono_Dor,Wet1_Cor,Wet2_Cor,Wet_H;
        BOOL bPassHdr;
//        int NumRec,NumOrbit,off,NumCycle;
        double DVUCurLon;
        int DVUCurYear,DVUCurDay,DVUCurTimeSec;
        int Count_Errors;
        char TrackType;

        double latitude,longitude;
//        long int filelen;

        AnsiString DATE,TIME,Buffer_tmp;
        AnsiString OldLFormat,OldSFormat,NewFormat;
        char OldSeparator,NewSeparator;

        TDateTime dt1958;

		void __fastcall Execute();

		envi_entete_header entete;
		envi_main_header envigdr;

/*    PGconn     *conn;
    PGresult   *res;*/

public:
        __fastcall EnviThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif
