//---------------------------------------------------------------------------

#ifndef TopexThreadH
#define TopexThreadH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include "structures.h"
#include "libpq-fe.h"

#include "fstream.h"

#include "main.h"

#include "gdr_tp.h"


//#include "libpq-fe.h"
//---------------------------------------------------------------------------
class TopexThread : public TThread
{
private:
protected:
        TStringList *ListOut;
        TStringList *DirList;
        TStringList *List_Debug;
        DynamicArray<stTleData> TleData_List;
        BOOL AltCount(void);
        BOOL GETPASSHDR (AnsiString);
        void decode(unsigned char *buf);
        BOOL CreatingTleDB (AnsiString Path_to_tle);
        void CalculatingMGDR (AnsiString Path_to_DATA);
        void GETBITS(char zn,bool *bits);
        AnsiString DATETIMEASTIMATION(int days,int ms,int mcs);
        BOOL GETDATETIMEDVUCUR(AnsiString String);

        TSearchRec sr;
        int H_SAT,H_Alt,Wet_Cor,Dry_Cor,EMB,Iono_Cor,INV_BAR,H_EOT,H_SET,H_LT,H_MSS,H_GEO,H_POL,Iono_Dor,Wet1_Cor,Wet2_Cor,Wet_H;
        BOOL bPassHdr;
        int NumRec,NumOrbit,off,NumCycle;
        double DVUCurLon;
        int DVUCurYear,DVUCurDay,DVUCurTimeSec;

        char TrackType;

        double latitude,longitude;
        long int filelen;

        AnsiString DATE,TIME,Buffer_tmp;
        AnsiString OldLFormat,OldSFormat,NewFormat;
        char OldSeparator,NewSeparator;

        TDateTime dt1958;

        void __fastcall Execute();

        struct_header stPassHdr;
        gdrm_tp_header gdrm;

/*    PGconn     *conn;
    PGresult   *res;*/

public:
        __fastcall TopexThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif

